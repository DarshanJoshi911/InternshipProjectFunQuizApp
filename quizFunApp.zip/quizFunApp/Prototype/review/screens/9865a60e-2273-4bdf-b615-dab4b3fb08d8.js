var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1611022314161.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1611022314161-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-9865a60e-2273-4bdf-b615-dab4b3fb08d8" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="SplashScreen" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/9865a60e-2273-4bdf-b615-dab4b3fb08d8-1611022314161.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/9865a60e-2273-4bdf-b615-dab4b3fb08d8-1611022314161-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/9865a60e-2273-4bdf-b615-dab4b3fb08d8-1611022314161-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed" customid="Image 1"   datasizewidth="352.0px" datasizeheight="476.0px" dataX="4.0" dataY="99.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/56a497f2-cea4-4ea5-aef0-24da1cd8d871.jpg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image_26"   datasizewidth="69.0px" datasizeheight="19.0px" dataX="138.0" dataY="361.0"   alt="image" systemName="./images/1cab8e47-de13-4c5d-bf6b-86f41ce813ae.svg" overlay="#A9A9A9">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="6px" version="1.1" viewBox="0 0 24 6" width="24px">\
          	    <!-- Generator: Sketch 48.2 (47327) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Icon</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_2-iPhone-X" stroke="none" stroke-width="1" transform="translate(-164.000000, -23.000000)">\
          	        <path d="M167,29 C165.343146,29 164,27.6568542 164,26 C164,24.3431458 165.343146,23 167,23 C168.656854,23 170,24.3431458 170,26 C170,27.6568542 168.656854,29 167,29 Z M176,29 C174.343146,29 173,27.6568542 173,26 C173,24.3431458 174.343146,23 176,23 C177.656854,23 179,24.3431458 179,26 C179,27.6568542 177.656854,29 176,29 Z M185,29 C183.343146,29 182,27.6568542 182,26 C182,24.3431458 183.343146,23 185,23 C186.656854,23 188,24.3431458 188,26 C188,27.6568542 186.656854,29 185,29 Z" fill="#9B9B9B" id="s-Image_2-Icon" style="fill:#A9A9A9 !important;" />\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;