var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1611022314161.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1611022314161-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-733f99a4-8f8d-4a9c-9a75-1d1c435ca03c" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Register" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/733f99a4-8f8d-4a9c-9a75-1d1c435ca03c-1611022314161.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/733f99a4-8f8d-4a9c-9a75-1d1c435ca03c-1611022314161-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/733f99a4-8f8d-4a9c-9a75-1d1c435ca03c-1611022314161-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed" customid="Image_71"   datasizewidth="38.0px" datasizeheight="37.0px" dataX="18.0" dataY="38.0"   alt="image" systemName="./images/80951f87-71f9-4509-9f58-af9155ba93d9.svg" overlay="#7D7D7D">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" fill="#7D7D7D" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="pie percentage richtext manualfit firer click commentable pin hpin-center non-processed-percentage non-processed-pin non-processed" customid="Button"   datasizewidth="95.5%" datasizeheight="57.0px" dataX="1.0" dataY="509.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Sign Up</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="input" datasizewidth="0.0px" datasizeheight="44.0px" >\
        <div id="s-Input_1" class="pie percentage text firer focusin focusout ie-background commentable pin hpin-center non-processed-percentage non-processed-pin non-processed" customid="Input_3"  datasizewidth="95.0%" datasizeheight="44.0px" dataX="1.0" dataY="91.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Enter Date of Birth"/></div></div>  </div></div></div>\
        <div id="shapewrapper-s-Line_1" customid="Line 1" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="95.0%" datasizeheight="1.0px" datasizewidthpx="342.0" datasizeheightpx="1.0" dataX="1.0" dataY="133.0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
                <g>\
                    <g>\
                        <path id="s-Line_1" class="pie percentage line shape non-processed-shape firer ie-background commentable pin hpin-center non-processed-percentage non-processed-pin non-processed" customid="Line 1" d="M 0.0 0.5 L 342.0 0.5"  >\
                        </path>\
                    </g>\
                </g>\
                <defs>\
                </defs>\
            </svg>\
        </div>\
        <div id="shapewrapper-s-Line_2" customid="Line 2" class="shapewrapper shapewrapper-s-Line_2 non-processed"   datasizewidth="95.0%" datasizeheight="2.0px" datasizewidthpx="342.0" datasizeheightpx="2.0" dataX="1.0" dataY="133.0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_2" class="svgContainer" style="width:100%;height:100%;">\
                <g>\
                    <g>\
                        <path id="s-Line_2" class="pie percentage line shape non-processed-shape firer ie-background commentable pin hpin-center non-processed-percentage non-processed-pin hidden non-processed" customid="Line 2" d="M 0.0 1.0 L 342.0 1.0"  >\
                        </path>\
                    </g>\
                </g>\
                <defs>\
                </defs>\
            </svg>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="input" datasizewidth="0.0px" datasizeheight="44.0px" >\
        <div id="s-Input_2" class="pie percentage text firer focusin focusout ie-background commentable pin hpin-center non-processed-percentage non-processed-pin non-processed" customid="Input_3"  datasizewidth="95.0%" datasizeheight="44.0px" dataX="1.0" dataY="194.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Enter Email"/></div></div>  </div></div></div>\
        <div id="shapewrapper-s-Line_3" customid="Line 3" class="shapewrapper shapewrapper-s-Line_3 non-processed"   datasizewidth="95.0%" datasizeheight="1.0px" datasizewidthpx="342.0" datasizeheightpx="1.0" dataX="1.0" dataY="236.0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_3" class="svgContainer" style="width:100%;height:100%;">\
                <g>\
                    <g>\
                        <path id="s-Line_3" class="pie percentage line shape non-processed-shape firer ie-background commentable pin hpin-center non-processed-percentage non-processed-pin non-processed" customid="Line 3" d="M 0.0 0.5 L 342.0 0.5"  >\
                        </path>\
                    </g>\
                </g>\
                <defs>\
                </defs>\
            </svg>\
        </div>\
        <div id="shapewrapper-s-Line_4" customid="Line 4" class="shapewrapper shapewrapper-s-Line_4 non-processed"   datasizewidth="95.0%" datasizeheight="2.0px" datasizewidthpx="342.0" datasizeheightpx="2.0" dataX="1.0" dataY="236.0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_4" class="svgContainer" style="width:100%;height:100%;">\
                <g>\
                    <g>\
                        <path id="s-Line_4" class="pie percentage line shape non-processed-shape firer ie-background commentable pin hpin-center non-processed-percentage non-processed-pin hidden non-processed" customid="Line 4" d="M 0.0 1.0 L 342.0 1.0"  >\
                        </path>\
                    </g>\
                </g>\
                <defs>\
                </defs>\
            </svg>\
        </div>\
      </div>\
\
\
      <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="input" datasizewidth="0.0px" datasizeheight="44.0px" >\
        <div id="s-Input_3" class="pie percentage text firer focusin focusout ie-background commentable pin hpin-center non-processed-percentage non-processed-pin non-processed" customid="Input_3"  datasizewidth="95.0%" datasizeheight="44.0px" dataX="1.0" dataY="292.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Enter Username"/></div></div>  </div></div></div>\
        <div id="shapewrapper-s-Line_5" customid="Line 5" class="shapewrapper shapewrapper-s-Line_5 non-processed"   datasizewidth="95.0%" datasizeheight="1.0px" datasizewidthpx="342.0" datasizeheightpx="1.0" dataX="1.0" dataY="345.0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_5" class="svgContainer" style="width:100%;height:100%;">\
                <g>\
                    <g>\
                        <path id="s-Line_5" class="pie percentage line shape non-processed-shape firer ie-background commentable pin hpin-center non-processed-percentage non-processed-pin non-processed" customid="Line 5" d="M 0.0 0.5 L 342.0 0.5"  >\
                        </path>\
                    </g>\
                </g>\
                <defs>\
                </defs>\
            </svg>\
        </div>\
        <div id="shapewrapper-s-Line_6" customid="Line 6" class="shapewrapper shapewrapper-s-Line_6 non-processed"   datasizewidth="95.0%" datasizeheight="2.0px" datasizewidthpx="342.0" datasizeheightpx="2.0" dataX="1.0" dataY="345.0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_6" class="svgContainer" style="width:100%;height:100%;">\
                <g>\
                    <g>\
                        <path id="s-Line_6" class="pie percentage line shape non-processed-shape firer ie-background commentable pin hpin-center non-processed-percentage non-processed-pin hidden non-processed" customid="Line 6" d="M 0.0 1.0 L 342.0 1.0"  >\
                        </path>\
                    </g>\
                </g>\
                <defs>\
                </defs>\
            </svg>\
        </div>\
      </div>\
\
\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="input" datasizewidth="0.0px" datasizeheight="44.0px" >\
        <div id="s-Input_4" class="pie percentage text firer focusin focusout ie-background commentable pin hpin-center non-processed-percentage non-processed-pin non-processed" customid="Input_3"  datasizewidth="95.0%" datasizeheight="44.0px" dataX="1.0" dataY="406.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Enter Password"/></div></div>  </div></div></div>\
        <div id="shapewrapper-s-Line_7" customid="Line 7" class="shapewrapper shapewrapper-s-Line_7 non-processed"   datasizewidth="95.0%" datasizeheight="1.0px" datasizewidthpx="342.0" datasizeheightpx="1.0" dataX="1.0" dataY="448.0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_7" class="svgContainer" style="width:100%;height:100%;">\
                <g>\
                    <g>\
                        <path id="s-Line_7" class="pie percentage line shape non-processed-shape firer ie-background commentable pin hpin-center non-processed-percentage non-processed-pin non-processed" customid="Line 7" d="M 0.0 0.5 L 342.0 0.5"  >\
                        </path>\
                    </g>\
                </g>\
                <defs>\
                </defs>\
            </svg>\
        </div>\
        <div id="shapewrapper-s-Line_8" customid="Line 8" class="shapewrapper shapewrapper-s-Line_8 non-processed"   datasizewidth="95.0%" datasizeheight="2.0px" datasizewidthpx="342.0" datasizeheightpx="2.0" dataX="1.0" dataY="448.0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_8" class="svgContainer" style="width:100%;height:100%;">\
                <g>\
                    <g>\
                        <path id="s-Line_8" class="pie percentage line shape non-processed-shape firer ie-background commentable pin hpin-center non-processed-percentage non-processed-pin hidden non-processed" customid="Line 8" d="M 0.0 1.0 L 342.0 1.0"  >\
                        </path>\
                    </g>\
                </g>\
                <defs>\
                </defs>\
            </svg>\
        </div>\
      </div>\
\
      <div id="s-Input_5" class="pie text firer commentable non-processed" customid="Input_4"  datasizewidth="345.0px" datasizeheight="46.0px" dataX="8.0" dataY="136.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="DATE OF BIRTH" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_6" class="pie text firer commentable non-processed" customid="Input_4"  datasizewidth="345.0px" datasizeheight="46.0px" dataX="8.5" dataY="239.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="EMAIL ADDRESS" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_7" class="pie text firer commentable non-processed" customid="Input_4"  datasizewidth="345.0px" datasizeheight="46.0px" dataX="8.0" dataY="348.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="USERNAME" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_8" class="pie text firer commentable non-processed" customid="Input_4"  datasizewidth="345.0px" datasizeheight="46.0px" dataX="8.0" dataY="451.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="PASSWORD" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed" customid="Image 3"   datasizewidth="235.0px" datasizeheight="67.0px" dataX="73.0" dataY="23.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/478e83a2-adfb-4b05-8c4c-0cf1cf51b682.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;