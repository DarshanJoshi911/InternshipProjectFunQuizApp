var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1611022314161.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1611022314161-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-ea8425a5-559b-4b05-bb41-58d7b31e45a0" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Categories" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/ea8425a5-559b-4b05-bb41-58d7b31e45a0-1611022314161.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/ea8425a5-559b-4b05-bb41-58d7b31e45a0-1611022314161-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/ea8425a5-559b-4b05-bb41-58d7b31e45a0-1611022314161-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Input_5" class="pie text firer commentable non-processed" customid="Input_4"  datasizewidth="345.0px" datasizeheight="46.0px" dataX="7.0" dataY="180.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="BROWSE BY SUBJECT" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="360.0px" datasizeheight="152.5px" dataX="-0.0" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/cca3430a-8d8a-4e64-8513-b9aaea4aeb7a.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Input_6" class="pie text firer commentable non-processed" customid="Input_4"  datasizewidth="345.0px" datasizeheight="46.0px" dataX="7.5" dataY="226.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="1, &nbsp;CATEGORY 1" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_7" class="pie text firer commentable non-processed" customid="Input_4"  datasizewidth="345.0px" datasizeheight="46.0px" dataX="15.0" dataY="328.2" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="3, &nbsp;CATEGORY 3" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_8" class="pie text firer commentable non-processed" customid="Input_4"  datasizewidth="345.0px" datasizeheight="46.0px" dataX="15.0" dataY="272.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="2, &nbsp;CATEGORY 2" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_9" class="pie text firer commentable non-processed" customid="Input_4"  datasizewidth="318.0px" datasizeheight="46.0px" dataX="21.0" dataY="379.7" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="4, &nbsp;CATEGORY 4" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_10" class="pie text firer commentable non-processed" customid="Input_4"  datasizewidth="331.5px" datasizeheight="46.0px" dataX="21.0" dataY="431.2" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="5, &nbsp;CATEGORY 5" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_11" class="pie text firer commentable non-processed" customid="Input_4"  datasizewidth="331.5px" datasizeheight="46.0px" dataX="21.0" dataY="489.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="6, &nbsp;CATEGORY 6" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="138.0px" datasizeheight="91.0px" dataX="15.0" dataY="89.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/39f21838-b0bb-41a2-8228-e3e711746b9a.jpg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="138.0px" datasizeheight="91.0px" dataX="187.5" dataY="89.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/39f21838-b0bb-41a2-8228-e3e711746b9a.jpg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Input-text" datasizewidth="0.0px" datasizeheight="44.0px" >\
        <div id="s-Input_1" class="pie percentage text firer commentable pin hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="Input-text_2"  datasizewidth="29.9%" datasizeheight="44.0px" dataX="23.0" dataY="89.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value=" &nbsp; &nbsp; &nbsp;Find" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="shapewrapper-s-Line_1" customid="Line 1" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="28.7%" datasizeheight="1.0px" datasizewidthpx="103.35402593630445" datasizeheightpx="1.0" dataX="214.0" dataY="132.0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
                <g>\
                    <g>\
                        <path id="s-Line_1" class="pie percentage line shape non-processed-shape firer ie-background commentable pin hpin-end non-processed-percentage non-processed-pin non-processed" customid="Line 1" d="M 0.0 0.5 L 103.35402593630445 0.5"  >\
                        </path>\
                    </g>\
                </g>\
                <defs>\
                </defs>\
            </svg>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Input-text" datasizewidth="0.0px" datasizeheight="44.0px" >\
        <div id="s-Input_2" class="pie percentage text firer commentable pin hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="Input-text_2"  datasizewidth="29.9%" datasizeheight="44.0px" dataX="206.0" dataY="94.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="Create" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="shapewrapper-s-Line_2" customid="Line 2" class="shapewrapper shapewrapper-s-Line_2 non-processed"   datasizewidth="28.7%" datasizeheight="1.0px" datasizewidthpx="103.35402593630445" datasizeheightpx="1.0" dataX="62.0" dataY="105.0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_2" class="svgContainer" style="width:100%;height:100%;">\
                <g>\
                    <g>\
                        <path id="s-Line_2" class="pie percentage line shape non-processed-shape firer ie-background commentable pin hpin-end non-processed-percentage non-processed-pin non-processed" customid="Line 2" d="M 0.0 0.5 L 103.35402593630445 0.5"  >\
                        </path>\
                    </g>\
                </g>\
                <defs>\
                </defs>\
            </svg>\
        </div>\
      </div>\
\
\
      <div id="s-Image_4" class="pie image firer click ie-background commentable non-processed" customid="Image_71"   datasizewidth="33.0px" datasizeheight="24.0px" dataX="7.0" dataY="15.0"   alt="image" systemName="./images/a65be7e5-5178-4a2a-b088-f4106768c36c.svg" overlay="#7D7D7D">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" fill="#7D7D7D" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;