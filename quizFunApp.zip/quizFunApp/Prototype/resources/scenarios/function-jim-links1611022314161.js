(function(window, undefined) {

  var jimLinks = {
    "27c20d47-b576-4ecd-87f1-184461630cbe" : {
      "Paragraph_1" : [
        "ea8425a5-559b-4b05-bb41-58d7b31e45a0"
      ],
      "Input_5" : [
        "f44958cd-ac11-425e-ac3f-edbe8f39a350"
      ],
      "Image_1" : [
        "733f99a4-8f8d-4a9c-9a75-1d1c435ca03c"
      ]
    },
    "f44958cd-ac11-425e-ac3f-edbe8f39a350" : {
      "Image_1" : [
        "27c20d47-b576-4ecd-87f1-184461630cbe"
      ],
      "Paragraph_1" : [
        "27c20d47-b576-4ecd-87f1-184461630cbe"
      ]
    },
    "ea8425a5-559b-4b05-bb41-58d7b31e45a0" : {
      "Image_4" : [
        "27c20d47-b576-4ecd-87f1-184461630cbe"
      ]
    },
    "733f99a4-8f8d-4a9c-9a75-1d1c435ca03c" : {
      "Image_1" : [
        "9de4894e-cbf5-497d-8ca1-462b3116b4ef"
      ],
      "Paragraph_1" : [
        "27c20d47-b576-4ecd-87f1-184461630cbe"
      ]
    },
    "9de4894e-cbf5-497d-8ca1-462b3116b4ef" : {
      "Paragraph_1" : [
        "733f99a4-8f8d-4a9c-9a75-1d1c435ca03c"
      ],
      "Paragraph_2" : [
        "27c20d47-b576-4ecd-87f1-184461630cbe"
      ]
    },
    "9865a60e-2273-4bdf-b615-dab4b3fb08d8" : {
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Paragraph_1" : [
        "733f99a4-8f8d-4a9c-9a75-1d1c435ca03c"
      ],
      "Paragraph_2" : [
        "27c20d47-b576-4ecd-87f1-184461630cbe"
      ],
      "Image_1" : [
        "fb8cc2f7-147a-4844-9247-2483c2cbe4e8"
      ]
    },
    "fb8cc2f7-147a-4844-9247-2483c2cbe4e8" : {
      "Paragraph_1" : [
        "733f99a4-8f8d-4a9c-9a75-1d1c435ca03c"
      ],
      "Paragraph_2" : [
        "27c20d47-b576-4ecd-87f1-184461630cbe"
      ],
      "Image_1" : [
        "9de4894e-cbf5-497d-8ca1-462b3116b4ef"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);